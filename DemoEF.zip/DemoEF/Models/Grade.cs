﻿namespace DemoEF.Models
{
    public class Grade
    {
        public string GradeName { get; set; }
        public int Lower_Bound { get; set; }
        public int Upper_Bound { get; set; }
    }
}
